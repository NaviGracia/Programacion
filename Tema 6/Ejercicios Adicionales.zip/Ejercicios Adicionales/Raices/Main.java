package Raices;

public class Main {
    public static void main(String[] args) {
        Raices ecuacion = new Raices(6, 10, 4); //creamos el objeto
        ecuacion.calcular(); //Calculamos 
    }
}
