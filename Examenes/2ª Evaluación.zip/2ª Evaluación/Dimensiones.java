public interface Dimensiones {
    public double calcularArea();
    public double calcularPerimetro();
}
