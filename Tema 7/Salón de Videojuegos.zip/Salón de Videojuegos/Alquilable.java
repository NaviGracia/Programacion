public interface Alquilable {
    int alquilar();

    int devolver();

    double precioFinal();
}
