public class Circunferencia {
    private Punto centro = new Punto();
    private int radio;
    public Circunferencia(int radio){
        this.radio=radio;
    }
}
