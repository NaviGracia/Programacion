public class Motores {
    private String nombre;

    Motores(String nombre){
        this.nombre = nombre;
    }

    public String getNombreMotor() {
        return nombre;
    }

}
