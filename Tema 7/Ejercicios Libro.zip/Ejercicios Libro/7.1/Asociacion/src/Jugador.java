public class Jugador {
    private String nombre;
    
    Jugador(String nombre){
        this.nombre = nombre;
    }

    public String getNombreJugador() {
        return nombre;
    }
}
