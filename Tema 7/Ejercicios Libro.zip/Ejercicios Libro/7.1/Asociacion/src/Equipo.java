public class Equipo {
    private String nombre;

    Equipo(String nombre){
        this.nombre = nombre;
    }

    public String getNombreEquipo() {
        return nombre;
    }
}
