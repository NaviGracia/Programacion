package Ejercicio12;

public abstract class Forma {
    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return super.toString();
    }

    public abstract int getIdentificador(); 
}
