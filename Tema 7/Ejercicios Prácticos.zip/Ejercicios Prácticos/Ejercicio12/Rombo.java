package Ejercicio12;

public class Rombo extends Forma{
    @Override
    public int getIdentificador() {
        // TODO Auto-generated method stub
        return 0;
    }
}
