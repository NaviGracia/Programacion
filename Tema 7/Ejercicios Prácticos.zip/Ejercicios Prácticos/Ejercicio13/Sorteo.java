package Ejercicio13;

public abstract class Sorteo{
    protected int posibilidades;
    public abstract int lanzar();
    }
    
