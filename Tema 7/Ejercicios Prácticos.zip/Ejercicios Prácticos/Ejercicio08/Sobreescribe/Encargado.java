package Ejercicio08.Sobreescribe;

public class Encargado extends Empleado{
    
}
