package Ejercicio08;

public class Empleado {
    private double sueldo;

    public double getSueldo() {
        return sueldo;
    }
}
