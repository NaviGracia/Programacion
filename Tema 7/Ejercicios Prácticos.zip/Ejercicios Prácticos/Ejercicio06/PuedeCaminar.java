package Ejercicio06;

public interface PuedeCaminar {
    void puedeCaminar();
}
