package Ejercicio06;

public class Felino extends Mamifero implements PuedeNadar{
    @Override
    public void puedeNadar() {}

}
