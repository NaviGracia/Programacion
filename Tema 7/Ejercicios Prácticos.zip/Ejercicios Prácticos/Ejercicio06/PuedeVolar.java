package Ejercicio06;

public interface PuedeVolar {
    void puedeVolar();
}
