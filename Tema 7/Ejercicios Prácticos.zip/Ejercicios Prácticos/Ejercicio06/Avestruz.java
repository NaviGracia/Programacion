package Ejercicio06;

public class Avestruz extends Aves{
    @Override
    public void puedeCaminar() {
        // TODO Auto-generated method stub
        System.out.println("El avestruz camina");
    }
}
