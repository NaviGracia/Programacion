package Ejercicio06;

public interface PuedeNadar {
    void puedeNadar();
}
