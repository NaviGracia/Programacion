package Ejercicio06;

public class Mamifero implements PuedeCaminar{
    @Override
    public void puedeCaminar() {}
}
