package Ejercicio06;

public class Tigre extends Felino{
    @Override
    public void puedeCaminar() {
        // TODO Auto-generated method stub
        System.out.println("El tigre camina");
    }

    @Override
    public void puedeNadar() {
        // TODO Auto-generated method stub
        System.out.println("El tigre nada");
    }
}
