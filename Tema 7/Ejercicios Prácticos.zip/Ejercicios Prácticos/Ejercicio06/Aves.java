package Ejercicio06;

public class Aves implements PuedeCaminar{
    @Override
    public void puedeCaminar() {}
}
