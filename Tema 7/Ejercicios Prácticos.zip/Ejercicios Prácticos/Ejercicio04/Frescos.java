package Ejercicio04;

public class Frescos extends Productos {

    public Frescos(int numLote, String fechaEnvasado, String fechaCaducidad, String paisOrigen) {
        super(numLote, fechaEnvasado, fechaCaducidad, paisOrigen);
    }
}
