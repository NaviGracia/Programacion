package Ejercicio15;

public class Vehiculo {
    public abstract class vehiculo{
        private int peso;
        public final void setPeso(int p){peso=p;}
        public abstract int getVelocidadActual();
        }
        //Si que puede tener descendencia y el método abstracto si que se puede sobreescribir
}
