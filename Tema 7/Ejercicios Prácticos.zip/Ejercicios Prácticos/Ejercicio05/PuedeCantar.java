package Ejercicio05;

public interface PuedeCantar {
     void cantar();
}
