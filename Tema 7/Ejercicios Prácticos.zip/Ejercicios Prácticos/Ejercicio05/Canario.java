package Ejercicio05;

public class Canario implements PuedeCantar{
    @Override
    public void cantar() {
        System.out.println("Kuru Kuru");
    }
}
