package Ejercicio05;

public class Gallo implements PuedeCantar{
    @Override
    public void cantar() {
        System.out.println("Kikiriki!!");
    }
}
