package Ejercicio09;

public class Prueba {
    protected String nombre;
    protected int ID;
    public String getIdent ( ) { return nombre;}
    public int getIdent ( ) { return ID;}
    //No porque no puede haber varios métodos con el mismo nombre en una misma clase
}
