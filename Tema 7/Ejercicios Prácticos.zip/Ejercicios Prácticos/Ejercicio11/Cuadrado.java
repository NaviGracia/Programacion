package Ejercicio11;

public class Cuadrado extends Forma{
    @Override
    public int getIdentificador() {
        // TODO Auto-generated method stub
        return 0;
    }
}
