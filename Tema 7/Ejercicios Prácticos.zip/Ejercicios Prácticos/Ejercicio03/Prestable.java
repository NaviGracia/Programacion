package Ejercicio03;

public interface Prestable {
    void prestar();

    void devolver();

    boolean prestado();
}
