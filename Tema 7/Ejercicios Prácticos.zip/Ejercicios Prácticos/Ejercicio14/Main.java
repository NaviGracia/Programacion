package Ejercicio14;

public class Main {
    public static void main(String[] args) {
        final String s1 = new String("Hola");
        String s2 = new String("Mundo");
        s1 = s1+s2;
        // Que el String s1 es final, es decir, que no se puede modificar

    }
}
