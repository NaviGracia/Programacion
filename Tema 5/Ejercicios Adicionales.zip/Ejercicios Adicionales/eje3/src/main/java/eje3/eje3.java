package eje3;

public class eje3 {
    public static void main(String[] args) {
        for(int y = 1; y<=100; y++){
            if ((y%2==0)&&(y%3==0)){
                System.out.println(y);
            }
        }
    }
}